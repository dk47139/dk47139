/*
	Author: Igor Sunzharovskyi.
	Author URI: http://sizam-design.com/
*/


/****** Helper JS *****/

/* hover Intent r7 */
(function($){$.fn.hoverIntent=function(handlerIn,handlerOut,selector){var cfg={interval:100,sensitivity:7,timeout:0};if(typeof handlerIn==="object"){cfg=$.extend(cfg,handlerIn)}else if($.isFunction(handlerOut)){cfg=$.extend(cfg,{over:handlerIn,out:handlerOut,selector:selector})}else{cfg=$.extend(cfg,{over:handlerIn,out:handlerIn,selector:handlerOut})}var cX,cY,pX,pY;var track=function(ev){cX=ev.pageX;cY=ev.pageY};var compare=function(ev,ob){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t);if((Math.abs(pX-cX)+Math.abs(pY-cY))<cfg.sensitivity){$(ob).off("mousemove.hoverIntent",track);ob.hoverIntent_s=1;return cfg.over.apply(ob,[ev])}else{pX=cX;pY=cY;ob.hoverIntent_t=setTimeout(function(){compare(ev,ob)},cfg.interval)}};var delay=function(ev,ob){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t);ob.hoverIntent_s=0;return cfg.out.apply(ob,[ev])};var handleHover=function(e){var ev=jQuery.extend({},e);var ob=this;if(ob.hoverIntent_t){ob.hoverIntent_t=clearTimeout(ob.hoverIntent_t)}if(e.type=="mouseenter"){pX=ev.pageX;pY=ev.pageY;$(ob).on("mousemove.hoverIntent",track);if(ob.hoverIntent_s!=1){ob.hoverIntent_t=setTimeout(function(){compare(ev,ob)},cfg.interval)}}else{$(ob).off("mousemove.hoverIntent",track);if(ob.hoverIntent_s==1){ob.hoverIntent_t=setTimeout(function(){delay(ev,ob)},cfg.timeout)}}};return this.on({'mouseenter.hoverIntent':handleHover,'mouseleave.hoverIntent':handleHover},cfg.selector)}})(jQuery);

/* equalHeightColumns.js 1.1 */
(function($){$.fn.equalHeightColumns=function(options){defaults={minWidth:-1,maxWidth:99999,setHeightOn:"min-height",defaultVal:0};var $this=$(this);options=$.extend({},defaults,options);var resizeHeight=function(){var windowWidth=$(window).width();if(options.minWidth<windowWidth&&options.maxWidth>windowWidth){var height=0;var highest=0;$this.css(options.setHeightOn,options.defaultVal);$this.each(function(){height=$(this).height();if(height>highest)highest=height});$this.css(options.setHeightOn,highest)}else $this.css(options.setHeightOn,
options.defaultVal)};resizeHeight();$(window).resize(resizeHeight);$this.find("img").load(resizeHeight);if(typeof options.afterLoading!=="undefined")$this.find(options.afterLoading).load(resizeHeight);if(typeof options.afterTimeout!=="undefined")setTimeout(function(){resizeHeight();if(typeof options.afterLoading!=="undefined")$this.find(options.afterLoading).load(resizeHeight)},options.afterTimeout)}})(jQuery);

/**
 * author Christopher Blum
 *    - based on the idea of Remy Sharp, http://remysharp.com/2009/01/26/element-in-view-event-plugin/
 *    - forked from http://github.com/zuk/jquery.inview/
 */
(function(d){var p={},e,a,h=document,i=window,f=h.documentElement,j=d.expando;d.event.special.inview={add:function(a){p[a.guid+"-"+this[j]]={data:a,$element:d(this)}},remove:function(a){try{delete p[a.guid+"-"+this[j]]}catch(d){}}};d(i).bind("scroll resize",function(){e=a=null});!f.addEventListener&&f.attachEvent&&f.attachEvent("onfocusin",function(){a=null});setInterval(function(){var k=d(),j,n=0;d.each(p,function(a,b){var c=b.data.selector,d=b.$element;k=k.add(c?d.find(c):d)});if(j=k.length){var b;
if(!(b=e)){var g={height:i.innerHeight,width:i.innerWidth};if(!g.height&&((b=h.compatMode)||!d.support.boxModel))b="CSS1Compat"===b?f:h.body,g={height:b.clientHeight,width:b.clientWidth};b=g}e=b;for(a=a||{top:i.pageYOffset||f.scrollTop||h.body.scrollTop,left:i.pageXOffset||f.scrollLeft||h.body.scrollLeft};n<j;n++)if(d.contains(f,k[n])){b=d(k[n]);var l=b.height(),m=b.width(),c=b.offset(),g=b.data("inview");if(!a||!e)break;c.top+l>a.top&&c.top<a.top+e.height&&c.left+m>a.left&&c.left<a.left+e.width?
(m=a.left>c.left?"right":a.left+e.width<c.left+m?"left":"both",l=a.top>c.top?"bottom":a.top+e.height<c.top+l?"top":"both",c=m+"-"+l,(!g||g!==c)&&b.data("inview",c).trigger("inview",[!0,m,l])):g&&b.data("inview",!1).trigger("inview",[!1])}}},250)})(jQuery);


/**
 * jquery.dlmenu.js v1.0.1
 * http://www.codrops.com
 *
 * Licensed under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
 * 
 * Copyright 2013, Codrops
 * http://www.codrops.com
 */
(function($,window,undefined){'use strict';var Modernizr=window.Modernizr,$body=$('body');$.DLMenu=function(options,element){this.$el=$(element);this._init(options)};$.DLMenu.defaults={animationClasses:{classin:'dl-animate-in-5',classout:'dl-animate-out-5'},onLevelClick:function(el,name){return false},onLinkClick:function(el,ev){return false}};$.DLMenu.prototype={_init:function(options){this.options=$.extend(true,{},$.DLMenu.defaults,options);this._config();var animEndEventNames={'WebkitAnimation':'webkitAnimationEnd','OAnimation':'oAnimationEnd','msAnimation':'MSAnimationEnd','animation':'animationend'},transEndEventNames={'WebkitTransition':'webkitTransitionEnd','MozTransition':'transitionend','OTransition':'oTransitionEnd','msTransition':'MSTransitionEnd','transition':'transitionend'};this.animEndEventName=animEndEventNames[Modernizr.prefixed('animation')]+'.dlmenu';this.transEndEventName=transEndEventNames[Modernizr.prefixed('transition')]+'.dlmenu',this.supportAnimations=Modernizr.cssanimations,this.supportTransitions=Modernizr.csstransitions;this._initEvents()},_config:function(){this.open=false;this.$trigger=this.$el.children('.dl-trigger');this.$menu=this.$el.children('ul.dl-menu');this.$menuitems=this.$menu.find('li:not(.dl-back)');this.$el.find('ul.dl-submenu').prepend('<li class="dl-back"><a href="#">'+translation.back+'</a></li>');this.$back=this.$menu.find('li.dl-back')},_initEvents:function(){var self=this;this.$trigger.on('click.dlmenu',function(){if(self.open){self._closeMenu()}else{self._openMenu()}return false});this.$menuitems.on('click.dlmenu',function(event){event.stopPropagation();var $item=$(this),$submenu=$item.children('ul.dl-submenu');if($submenu.length>0){var $flyin=$submenu.clone().css('opacity',0).insertAfter(self.$menu),onAnimationEndFn=function(){self.$menu.off(self.animEndEventName).removeClass(self.options.animationClasses.classout).addClass('dl-subview');$item.addClass('dl-subviewopen').parents('.dl-subviewopen:first').removeClass('dl-subviewopen').addClass('dl-subview');$flyin.remove()};setTimeout(function(){$flyin.addClass(self.options.animationClasses.classin);self.$menu.addClass(self.options.animationClasses.classout);if(self.supportAnimations){self.$menu.on(self.animEndEventName,onAnimationEndFn)}else{onAnimationEndFn.call()}self.options.onLevelClick($item,$item.children('a:first').text())});return false}else{self.options.onLinkClick($item,event)}});this.$back.on('click.dlmenu',function(event){var $this=$(this),$submenu=$this.parents('ul.dl-submenu:first'),$item=$submenu.parent(),$flyin=$submenu.clone().insertAfter(self.$menu);var onAnimationEndFn=function(){self.$menu.off(self.animEndEventName).removeClass(self.options.animationClasses.classin);$flyin.remove()};setTimeout(function(){$flyin.addClass(self.options.animationClasses.classout);self.$menu.addClass(self.options.animationClasses.classin);if(self.supportAnimations){self.$menu.on(self.animEndEventName,onAnimationEndFn)}else{onAnimationEndFn.call()}$item.removeClass('dl-subviewopen');var $subview=$this.parents('.dl-subview:first');if($subview.is('li')){$subview.addClass('dl-subviewopen')}$subview.removeClass('dl-subview')});return false})},closeMenu:function(){if(this.open){this._closeMenu()}},_closeMenu:function(){var self=this,onTransitionEndFn=function(){self.$menu.off(self.transEndEventName);self._resetMenu()};this.$menu.removeClass('dl-menuopen');this.$menu.addClass('dl-menu-toggle');this.$trigger.removeClass('dl-active');if(this.supportTransitions){this.$menu.on(this.transEndEventName,onTransitionEndFn)}else{onTransitionEndFn.call()}this.open=false},openMenu:function(){if(!this.open){this._openMenu()}},_openMenu:function(){var self=this;$body.off('click').on('click.dlmenu',function(){self._closeMenu()});this.$menu.addClass('dl-menuopen dl-menu-toggle').on(this.transEndEventName,function(){$(this).removeClass('dl-menu-toggle')});this.$trigger.addClass('dl-active');this.open=true},_resetMenu:function(){this.$menu.removeClass('dl-subview');this.$menuitems.removeClass('dl-subview dl-subviewopen')}};var logError=function(message){if(window.console){window.console.error(message)}};$.fn.dlmenu=function(options){if(typeof options==='string'){var args=Array.prototype.slice.call(arguments,1);this.each(function(){var instance=$.data(this,'dlmenu');if(!instance){logError("cannot call methods on dlmenu prior to initialization; "+"attempted to call method '"+options+"'");return}if(!$.isFunction(instance[options])||options.charAt(0)==="_"){logError("no such method '"+options+"' for dlmenu instance");return}instance[options].apply(instance,args)})}else{this.each(function(){var instance=$.data(this,'dlmenu');if(instance){instance._init()}else{instance=$.data(this,'dlmenu',new $.DLMenu(options,this))}})}return this}})(jQuery,window);


/***** BASIC CUSTOM JS *****/


jQuery(document).ready(function($) {
	'use strict';

    var res_nav = $("header .top_menu").html();
    $("header .responsive_nav_wrap").append(res_nav);
    $( 'header .responsive_nav_wrap ul.menu' ).wrap(function() {
      return "<div id='dl-menu' class='dl-menuwrapper'></div>";
    });
    $( 'header .responsive_nav_wrap ul.menu' ).attr('class', 'dl-menu');
    $( "header .responsive_nav_wrap #dl-menu" ).prepend( "<button class='dl-trigger'><i class='fa fa-bars'></i></button>" );
    $( "header .responsive_nav_wrap #dl-menu" ).find('.sub-menu').attr('class', 'dl-submenu');


  /* responsive menu init */
  $( '#dl-menu' ).dlmenu();

   /* gallery hover */
	$(".gallery-pics li").hover(function(){
        $(this).children('.gp-overlay').stop(true, true).fadeIn(500);
    }, function(){
        $(this).children('.gp-overlay').stop(true, true).fadeOut(500);
    });

  /* scroll to # */
  $('a[href^="#"].rehub_scroll, #c_menu a').bind('click.smoothscroll',function (e) {
    e.preventDefault();
    var target = this.hash,
    $target = $(target);
    $('html, body').stop().animate({
      'scrollTop': $target.offset().top
    }, 500, 'swing', function () {
      window.location.hash = target;
    });
  });
  
  /* custom inputs */
    if ($("div,p").hasClass("input_styled")) {
        $(".input_styled input").customInput();
    } 	
	
    /* tabs */
    $('.tabs-menu').delegate('li:not(.current)', 'click', function() {
        $(this).addClass('current').siblings().removeClass('current').parents('.tabs').find('.tabs-item').hide().eq($(this).index()).fadeIn(700);
    })
    $('.tabs-menu li:first-child').trigger('click');

    /* review woo tabs */
    $('.rehub_woo_tabs_menu').delegate('li:not(.current)', 'click', function() {
        $(this).addClass('current').siblings().removeClass('current').parents('.rehub_woo_review').find('.rehub_woo_review_tabs').hide().eq($(this).index()).fadeIn(700);
    })
    $('.rehub_woo_tabs_menu li:first-child').trigger('click');
    $('.btn_offer_block.choose_offer_woo').click(function(event){		
		event.preventDefault();
		$('.rehub_woo_tabs_menu li.woo_deals_tab').trigger('click');
	});
    
  	/* widget dropdown */
  	$('.cat_widget_custom .children').parent().find('a').append('<span class="drop_list">&nbsp; +</span>');  
	$('.tabs-item .drop_list').click(function() {
       $(this).parent().parent().find('.children').slideToggle();
        return false
    });	
	
	// Footer equal column height
	$('.footer_widget').equalHeightColumns({
    	minWidth: 767,
    	afterTimeout: 500
    });				
});

/* menu */
showNav = function(){'use strict'; jQuery(this).find('> .sub-menu').slideDown(); }
hideNav = function(){'use strict'; jQuery(this).find('> .sub-menu').slideUp();}
jQuery('nav.top_menu > ul > li.menu-item-has-children').hoverIntent({
	sensitivity: 7, // number = sensitivity threshold (must be 1 or higher)
	interval: 100, // number = milliseconds of polling interval
	over: showNav, // function = onMouseOver callback (required)
	timeout: 120, // number = milliseconds delay before onMouseOut function call
	out: hideNav // function = onMouseOut callback (required)
})

// User Rate functions
jQuery(document).on('mousemove', '.user-rate-active' , function (e) {
    var rated = jQuery(this);
    if( rated.hasClass('rated-done') ){
      return false;
    }
    if (!e.offsetX){
      e.offsetX = e.clientX - jQuery(e.target).offset().left;
    }
    var offset = e.offsetX + 4;
    if (offset > 100) {
      offset = 100;
    }
    rated.find('.user-rate-image span').css('width', offset + '%');
    var score = Math.floor(((offset / 10) * 5)) / 10;
    if (score > 5) {
      score = 5;
    }
});
jQuery(document).on('click', '.user-rate-active' , function (e) {
    var rated = jQuery(this);
    if( rated.hasClass('rated-done') ){
      return false;
    }
    var gg = rated.find('.user-rate-image span').width();
    rated.find('.user-rate-image').hide();
    rated.append('<span class="rehub-rate-load"></span>');
    if (gg > 100) {
      gg = 100;
    }
    ngg = (gg*5)/100;
    var post_id = rated.attr('data-id');
    var numVotes = rated.parent().find('.userrating-count').text();
    jQuery.post(rehub.ajaxurl, { action:'rehub_rate_post' , post:post_id , value:ngg}, function(data) {
    var post_rateed = '.rate-post-'+post_id;
      jQuery( post_rateed ).addClass('rated-done').attr('data-rate',gg);
      rated.find('.user-rate-image span').width(gg+'%');
      
      jQuery(".rehub-rate-load").fadeOut(function () {

        rated.parent().find('.userrating-score').html( ngg );
        
        if( (jQuery(rated.parent().find('.userrating-count'))).length > 0 ){
          numVotes =  parseInt(numVotes)+1;
          rated.parent().find('.userrating-count').html(numVotes);
        }else{
          rated.parent().find('small').hide();
        }
        rated.parent().find('strong').html(rehub.your_rating);
        
        rated.find('.user-rate-image').fadeIn();
      });
    }, 'html');
    return false;
});
jQuery(document).on('mouseleave', '.user-rate-active' , function (e) {
    var rated = jQuery(this);
    if( rated.hasClass('rated-done') ){
      return false;
    }
    var post_rate = rated.attr('data-rate');
    rated.find(".user-rate-image span").css('width', post_rate + '%');
});

// Rate bar annimation
jQuery(function($){
'use strict';	
  $(document).ready(function(){   
    $('.rate_bar_wrap').bind('inview', function(event, visible) {
      if (visible) {
        $('.rate-bar').each(function(){
         $(this).find('.rate-bar-bar').animate({ width: $(this).attr('data-percent') }, 1500 );
         $('.rate_bar_wrap').unbind('inview');
        });
      }
    });

    $('article .rate-line').bind('inview', function(event, visible) {
      if (visible) {
        $('.rate-line .line').each(function(){
         $(this).find('.filled').animate({ width: $(this).attr('data-percent') }, 1500 );
         $('article .rate-line').unbind('inview');
        });
      }
    });

  });
});  

jQuery(document).ready(function() {

  // Google Plus Button
  var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
  po.src = 'https://apis.google.com/js/plusone.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);

});  

//Scroll To top
jQuery(window).scroll(function(){
'use strict';	
  if (jQuery(this).scrollTop() > 100) {
    jQuery('#topcontrol').css({bottom:"15px"});
  } else {
    jQuery('#topcontrol').css({bottom:"-100px"});
  }
});